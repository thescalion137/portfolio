import React from 'react';
import Contact from '../components/Contact/Contact';

export default function ContactPage(props) {
  return <Contact data={props.data} />;
}
