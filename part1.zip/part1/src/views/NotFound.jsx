import React from 'react';

export default function NotFound() {
  return <div className='container-fluid'></div>;
}
